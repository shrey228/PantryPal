const { sendError } = require('../utils/response');

const notFound = (req, res, next) => {
  const error = new Error(`Not Found - ${req.originalUrl}`);
  res.status(404);
  next(error);
};

const errorHandler = (err, req, res, next) => {
  const statusCode = res.statusCode === 200 ? 500 : res.statusCode;
  console.error(`[Error Handler] ${err.stack}`);
  return sendError(
    res,
    err.message || 'Internal Server Error',
    {
      stack: process.env.NODE_ENV === 'production' ? null : err.stack,
    },
    statusCode
  );
};

module.exports = { notFound, errorHandler };
