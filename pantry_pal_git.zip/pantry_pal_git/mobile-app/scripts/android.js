const { spawn } = require('node:child_process');
const path = require('node:path');

delete process.env.JAVA_TOOL_OPTIONS;

if (!process.env.JAVA_HOME && process.platform === 'darwin') {
  process.env.JAVA_HOME = '/opt/homebrew/opt/openjdk@17';
}

const operation = process.argv[2];
let command;
let args;
let cwd = process.cwd();

if (operation === 'run') {
  command = 'react-native';
  args = ['run-android'];
} else if (operation === 'assembleDebug' || operation === 'assembleRelease') {
  cwd = path.join(__dirname, '..', 'android');
  command = process.platform === 'win32' ? 'gradlew.bat' : './gradlew';
  args = [operation];
} else {
  console.error(`Unsupported Android operation: ${operation}`);
  process.exitCode = 1;
  return;
}

const child = spawn(command, args, {
  cwd,
  env: process.env,
  shell: process.platform === 'win32',
  stdio: 'inherit',
});

child.on('error', (error) => {
  console.error(`Unable to start Android command: ${error.message}`);
  process.exitCode = 1;
});

child.on('close', (code) => {
  process.exitCode = code ?? 1;
});
